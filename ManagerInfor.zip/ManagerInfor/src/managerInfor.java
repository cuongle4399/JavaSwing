import java.awt.EventQueue;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.*;

public class managerInfor extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					managerInfor frame = new managerInfor();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
					frame.setResizable(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public void tabSeleted(JButton x , JButton y, JButton z) {
		x.setForeground(Color.RED);
		y.setForeground(Color.BLACK);
		z.setForeground(Color.BLACK);
	}
	private JTabbedPane tabbedPane;
	private JButton btnTrangChu;
	private JButton btnThongTin;
	private JButton btnMang;
	private Timer timerTienTrinh;
	private JTextArea txtALichSu;
	private JProgressBar prcBTienTrinh;
	private JTextArea txtADanhSachWifi;
	private int load = 0;
	private JButton btnPin;
	private JButton btnCPU;
	private Timer timerLichSuConnect;
	private boolean a= false,b = false;
	
		
	public managerInfor() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Quản lý hệ điều hành");
		setBounds(100, 100, 975, 530);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(192, 192, 192));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Timer timerPin = new Timer(10000, new ActionListener() {
			public void actionPerformed(ActionEvent a) {
				btnPin.setText(thongTin.getThongTin(4));
			}
		});
		Timer timerCPU = new Timer(7000, new ActionListener() {
			public void actionPerformed(ActionEvent a) {
				btnCPU.setText(thongTin.getThongTin(5));
			}
		});
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(192, 192, 192));
		panel.setBounds(0, 114, 177, 311);
		contentPane.add(panel);
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		
		btnTrangChu = new JButton("Trang Chủ");
		btnTrangChu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(0);
				tabSeleted(btnTrangChu,btnThongTin,btnMang);
				if(a) {
					timerCPU.stop();
				}
				else if (b) {
					timerPin.stop();
				}
			}
		});
		btnTrangChu.setMaximumSize(new Dimension(187, 50));
		panel.add(btnTrangChu);
	
		btnThongTin = new JButton("Thông tin máy");
		btnThongTin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(1);
				tabSeleted(btnThongTin,btnMang,btnTrangChu);
				timerPin.start();
				timerCPU.start();
				a= true;
				b = true;
			}
		});
		btnThongTin.setMaximumSize(new Dimension(187, 50));
		panel.add(btnThongTin);
		
		btnMang = new JButton("Mạng");
		btnMang.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(2);
				tabSeleted(btnMang,btnThongTin,btnTrangChu);
						txtADanhSachWifi.setText(thongTin.getThongTin(2));
						if(a) {
							timerCPU.stop();
						}
						else if (b) {
							timerPin.stop();
						}
			}
		});
		btnMang.setMaximumSize(new Dimension(187, 50));
		panel.add(btnMang);
		
		JLabel lblBanQuyen = new JLabel("@Cuong_Le");
		lblBanQuyen.setBounds(830, -3, 121, 30);
		contentPane.add(lblBanQuyen);
		lblBanQuyen.setHorizontalAlignment(SwingConstants.CENTER);
		lblBanQuyen.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblBanQuyen.setMaximumSize(new Dimension(187, 40));
		
		JToggleButton btnGiaoDien = new JToggleButton("OFF");
		btnGiaoDien.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(btnGiaoDien.getText() == "OFF") {
					btnGiaoDien.setText("ON");
					panel.setBackground(Color.DARK_GRAY);
					contentPane.setBackground(Color.DARK_GRAY);
					lblBanQuyen.setForeground(Color.WHITE);
				}
				else {
					btnGiaoDien.setText("OFF");
					panel.setBackground(Color.LIGHT_GRAY);
					contentPane.setBackground(Color.LIGHT_GRAY);
					lblBanQuyen.setForeground(Color.BLACK);
				}
			}
		});
		btnGiaoDien.setBounds(54, 462, 62, 21);
		contentPane.add(btnGiaoDien);
		
		tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(178, 0, 783, 493);
		contentPane.add(tabbedPane);
		
		JPanel panel_TrangChu = new JPanel();
		tabbedPane.addTab("Trang chủ", null, panel_TrangChu, null);
		panel_TrangChu.setLayout(null);
		
		timerTienTrinh = new Timer(0,new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (prcBTienTrinh.getValue() <= 100) {
					load+= 3;
					prcBTienTrinh.setValue(load);
				}
				else  {
					timerTienTrinh.stop();
				}
			}
		});
		JButton btnUpdate = new JButton("Cập nhập phiên bản mới");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				prcBTienTrinh.setValue(load);
					timerTienTrinh.start();
					load = 0;
					prcBTienTrinh.setBackground(Color.WHITE);
					prcBTienTrinh.setForeground(Color.BLACK);
				}
		});
		btnUpdate.setBounds(233, 230, 243, 36);
		panel_TrangChu.add(btnUpdate);
		
		prcBTienTrinh = new JProgressBar();
		prcBTienTrinh.setFont(new Font("Monospaced", Font.BOLD, 10));
		prcBTienTrinh.setStringPainted(true);
		prcBTienTrinh.setBounds(233, 313, 243, 14);
		panel_TrangChu.add(prcBTienTrinh);
		
		JLabel lblTienTrinh = new JLabel("Tiến Trình");
		lblTienTrinh.setHorizontalAlignment(SwingConstants.CENTER);
		lblTienTrinh.setBounds(233, 276, 243, 27);
		panel_TrangChu.add(lblTienTrinh);
		
		JPanel pane_ThongTin = new JPanel();
		tabbedPane.addTab("Thông tin", null, pane_ThongTin, null);
		pane_ThongTin.setLayout(null);
		
		JLabel lblCPU = new JLabel("CPU");
		lblCPU.setHorizontalAlignment(SwingConstants.CENTER);
		lblCPU.setBounds(285, 10, 45, 13);
		pane_ThongTin.add(lblCPU);
		
		btnCPU = new JButton("% CPU đang xử lý");
		btnCPU.setBounds(10, 6, 265, 21);
		pane_ThongTin.add(btnCPU);
		
		JLabel lblPin = new JLabel("PIN");
		lblPin.setHorizontalAlignment(SwingConstants.CENTER);
		lblPin.setBounds(437, 10, 45, 13);
		pane_ThongTin.add(lblPin);
		
		btnPin = new JButton("%Pin");
		btnPin.setBounds(492, 6, 276, 21);
		pane_ThongTin.add(btnPin);
		
		JTextArea txtAInfo = new JTextArea();
		txtAInfo.setFont(new Font("Monospaced", Font.BOLD, 16));
		txtAInfo.setEditable(false);
		txtAInfo.setLineWrap(true);
		txtAInfo.setText(thongTin.getThongTin(0));
		JScrollPane cuonInfo = new JScrollPane(txtAInfo);
		cuonInfo.setBounds(10,33,758,384);
		pane_ThongTin.add(cuonInfo);
		
		JButton btnCopyInfor = new JButton("Sao chép thông tin máy");
		btnCopyInfor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					StringSelection stringSelection = new StringSelection(txtAInfo.getText());
					Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
					clipboard.setContents(stringSelection, null);
					JOptionPane.showMessageDialog(null, "Sao chép thành công", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
				}
				catch (Exception a) {
					JOptionPane.showMessageDialog(null, "Lỗi", "Thông báo", JOptionPane.ERROR_MESSAGE);
				}
				
			}});
		btnCopyInfor.setBounds(10, 427, 592, 29);
		pane_ThongTin.add(btnCopyInfor);
		
		JButton btnThongTinChiTiet = new JButton("Xem chi tiết hơn");
		btnThongTinChiTiet.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtAInfo.setText(thongTin.getThongTin(1));
			}
		});
		btnThongTinChiTiet.setBounds(624, 427, 144, 29);
		pane_ThongTin.add(btnThongTinChiTiet);
		
		JPanel panelMang = new JPanel();
		tabbedPane.addTab("Mạng", null, panelMang, null);
		panelMang.setLayout(null);
		
		JButton btnCopyHistoryWifi = new JButton("Sao chép lịch sử kết nối wifi");
		btnCopyHistoryWifi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					StringSelection text1 = new StringSelection(txtALichSu.getText());
					Clipboard clipBoard1 = Toolkit.getDefaultToolkit().getSystemClipboard();
					clipBoard1.setContents(text1, null);
					JOptionPane.showMessageDialog(null, "Sao chép thành công", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
				}
				catch (Exception a) {
					JOptionPane.showMessageDialog(null, "Có cái j đâu mà copy ", "Thông báo", JOptionPane.ERROR_MESSAGE);
				}
				
				
			}
		});
		btnCopyHistoryWifi.setBounds(413, 437, 250, 25);
		panelMang.add(btnCopyHistoryWifi);
		
		JButton btnCopyListWifi = new JButton("Sao chép danh sách wifi");
		btnCopyListWifi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String textWifi = txtADanhSachWifi.getText();
					StringSelection textvip1 = new StringSelection(textWifi);
					Clipboard clipboadWifi = Toolkit.getDefaultToolkit().getSystemClipboard();
					clipboadWifi.setContents(textvip1,null);
					JOptionPane.showMessageDialog(null, "Sao chép thành công","Thông báo", JOptionPane.NO_OPTION);
			
				}
				catch(Exception a) {
					JOptionPane.showMessageDialog(null, "Lỗi sao chép","Thông báo", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnCopyListWifi.setBounds(10, 434, 199, 31);
		panelMang.add(btnCopyListWifi);
		
		JTabbedPane tabbedPane_Internet = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_Internet.setBounds(10, 10, 758, 417);
		panelMang.add(tabbedPane_Internet);
		
		JPanel panel_DanhSachWifi = new JPanel();
		tabbedPane_Internet.addTab("Danh sách Wifi", null, panel_DanhSachWifi, null);
		panel_DanhSachWifi.setLayout(new CardLayout(0, 0));
		
		txtADanhSachWifi = new JTextArea();
		txtADanhSachWifi.setEditable(false);
		txtADanhSachWifi.setLineWrap(true);
		txtADanhSachWifi.setFont(new Font("tahoma",Font.BOLD, 18));
		JScrollPane jcrollPane_Wifi = new JScrollPane(txtADanhSachWifi);
		panel_DanhSachWifi.add(jcrollPane_Wifi);
		
		JPanel panel_LichSuConect = new JPanel();
		tabbedPane_Internet.addTab("Lịch sử kết nối", null, panel_LichSuConect, null);
		panel_LichSuConect.setLayout(new CardLayout(0, 0));
		
		txtALichSu = new JTextArea();
		txtALichSu.setEditable(false);
		txtALichSu.setLineWrap(true);
		txtALichSu.setCaretPosition(0);
		txtALichSu.setFont(new Font("tahoma",Font.BOLD, 18));
		JScrollPane cuonHistoryConnect= new JScrollPane(txtALichSu);
		panel_LichSuConect.add(cuonHistoryConnect);
		
		tabbedPane_Internet.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				int selection = tabbedPane_Internet.getSelectedIndex();
				if(selection == 1) {
					timerLichSuConnect= new Timer(0, new ActionListener() {
						public void actionPerformed(ActionEvent a) {
							txtALichSu.setText(thongTin.getThongTin(3));
							((Timer)a.getSource()).stop();
						}
					});
					timerLichSuConnect.start();
				}
			}
		});
	}
}
