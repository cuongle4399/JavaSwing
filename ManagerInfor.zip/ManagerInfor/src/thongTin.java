import java.io.BufferedReader;
import java.io.InputStreamReader;
public class thongTin {
	public static String getThongTin(int x){
		String result = "";
		String command;
		try {
		   if (x == 0) {
			   command= "systeminfo | findstr /V /C:\"Virtualization-based\" /C:\"Required Security Properties\" /C:\"Base Virtualization Support\" /C:\"Secure Boot\" /C:\"DMA Protection\" /C:\"UEFI Code Readonly\" /C:\"SMM Security Mitigations\" /C:\"Mode Based Execution Control\" /C:\"APIC Virtualization\" /C:\"Hypervisor enforced Code Integrity\" /C:\"App Control for Business\" /C:\"Hyper-V Requirements\" /C:\"IP address\" /C:\"Connection Name\" /C:\"Status\" /C:\"Services Configured\" /C:\"Services Running\"\r\n"
			   		+ "";
		   }
			else if (x== 1) {
				command = "systeminfo";
			}
			else if (x == 2) {
				command = "netsh wlan show profiles";
			}
			else if(x == 3) {
				command= "powershell -Command \"Get-WinEvent -LogName 'Microsoft-Windows-NetworkProfile/Operational' | Where-Object { $_.Message -match 'connected|disconnected' } | Select-Object @{Name='TimeCreated';Expression={ $_.TimeCreated.ToString('yyyy-MM-dd HH:mm:ss:fff') }}, Message | Sort-Object TimeCreated\"\r\n";
			}
			else if (x == 4) {
				command = "wmic path Win32_Battery get EstimatedChargeRemaining\r\n";
			}
			else {
				
				command = "wmic cpu get loadpercentage\r\n";
			}
			ProcessBuilder processbuilder = new ProcessBuilder("cmd.exe","/c",command);
			processbuilder.start();
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(processbuilder.start().getInputStream()));
			String line;
			
			while((line = bufferedReader.readLine()) != null){
					result += line +'\n';
			}
		}
		catch (Exception a) {
			result = "Lỗi ok";
		}
		return result;
	}
}
